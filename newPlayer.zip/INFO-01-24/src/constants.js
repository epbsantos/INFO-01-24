export const scaleFactor = 2;

export const dialogueData = {
  placa1: 'Bem vindo ao inforgŕafico da turma de <b>front2</b> do curso de <a href="https://tsi.td.utfpr.edu.br/" target="_blank"><b>TSI</b></a>, UTFPR Toledo PR. Ande a vontade',
  placa2: 'Outro texto! <br> <img src="https://www.conexaoambiental.pr.gov.br/sites/conexao-ambiental/arquivos_restritos/files/styles/escala_940_largura_/public/imagem/2022-12/capa_programa_estadual_0.webp?itok=LusKjicW">',
  txt1:   'Colocar os textos sobre educação ambiental.',


  exit: `If you want to exit JSLegendDev's portfolio, just close the tab.`,
};
